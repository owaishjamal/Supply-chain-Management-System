<table class="table_mainWrapper">
<tr>
<td id="td_aside">

<aside>
	<a href="../manufacturer/edit_profile.php">Edit Profile</a><!--
	--><a href="../manufacturer/add_product.php">Add Products</a><!--
	--><a href="../manufacturer/manage_stock.php">Manage Stock</a><!--
	--><a href="../manufacturer/view_unit.php">Manage Unit</a><!--
	--><a href="../manufacturer/view_category.php">Manage Category</a>
</aside>

</td>
<td id="td_section">
<a href="../logout.php"><input type="button" value="Log out" class="submit_button" style="float:right;margin:10px;"/></a>