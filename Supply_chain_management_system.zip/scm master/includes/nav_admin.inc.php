<nav>
	<a href="../admin/index.php">Home</a><!--
	--><a href="../admin/view_retailer.php">Retailers</a><!--
	--><a href="../admin/view_manufacturer.php">Manufacturers</a><!--

	--><a href="../admin/view_products.php">Products</a><!--
	--><a href="../admin/view_orders.php">Orders</a><!--
	--><a href="../admin/view_invoice.php">Invoice</a>
</nav>
