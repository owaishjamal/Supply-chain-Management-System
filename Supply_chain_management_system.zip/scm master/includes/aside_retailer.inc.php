<table class="table_mainWrapper">
<tr>
<td id="td_aside">

<aside>
	<a href="../retailer/order_items.php">New Order</a><!--
	--><a href="../retailer/edit_profile.php">Edit Profile</a>
</aside>

</td>
<td id="td_section">
<a href="../logout.php"><input type="button" value="Log out" class="submit_button" style="float:right;margin:10px;"/></a>