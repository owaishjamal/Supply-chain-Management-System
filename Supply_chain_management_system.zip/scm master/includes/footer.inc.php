</td>
</tr>
</table>

<footer>Supply Chain Management for Easy foods Bakery.</footer>