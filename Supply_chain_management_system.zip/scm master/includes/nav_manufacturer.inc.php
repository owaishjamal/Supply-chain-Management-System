<nav>
	<a href="index.php">Home</a><!--
	--><a href="../manufacturer/view_retailer.php">Retailers</a><!--

	--><a href="../manufacturer/view_products.php">Products</a><!--
	--><a href="../manufacturer/view_orders.php">Orders</a><!--
	--><a href="../manufacturer/view_invoice.php">Invoice</a>
</nav>